package com.loyalty.authorization.repository;

public interface IAuthorizationRepository<I,O> {
	public O getInfoClient(I request);
}
