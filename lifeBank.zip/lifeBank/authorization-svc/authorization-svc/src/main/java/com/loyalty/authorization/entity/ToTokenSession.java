package com.loyalty.authorization.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the to_token_session database table.
 * 
 */
@Entity
@Table(name="to_token_session")
@NamedQuery(name="ToTokenSession.findAll", query="SELECT t FROM ToTokenSession t")
public class ToTokenSession implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="to_code")
	private Integer toCode;

	@Column(name="to_create_hour")
	private String toCreateHour;

	@Column(name="to_expiration_hour")
	private String toExpirationHour;

	@Column(name="to_token")
	private Integer toToken;

	//bi-directional many-to-one association to CliClientInformation
	@ManyToOne
	@JoinColumn(name="to_cli_code")
	private CliClientInformation cliClientInformation;

	public ToTokenSession() {
	}

	public Integer getToCode() {
		return this.toCode;
	}

	public void setToCode(Integer toCode) {
		this.toCode = toCode;
	}

	public String getToCreateHour() {
		return this.toCreateHour;
	}

	public void setToCreateHour(String toCreateHour) {
		this.toCreateHour = toCreateHour;
	}

	public String getToExpirationHour() {
		return this.toExpirationHour;
	}

	public void setToExpirationHour(String toExpirationHour) {
		this.toExpirationHour = toExpirationHour;
	}

	public Integer getToToken() {
		return this.toToken;
	}

	public void setToToken(Integer toToken) {
		this.toToken = toToken;
	}

	public CliClientInformation getCliClientInformation() {
		return this.cliClientInformation;
	}

	public void setCliClientInformation(CliClientInformation cliClientInformation) {
		this.cliClientInformation = cliClientInformation;
	}

}