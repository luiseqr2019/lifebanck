package com.loyalty.authorizationsvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthorizationSvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthorizationSvcApplication.class, args);
	}

}
