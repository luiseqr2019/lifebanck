package com.loyalty.authorization.repository.implementation;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import com.loyalty.authorization.entity.CliClientInformation;
import com.loyalty.authorization.repository.IAuthorizationRepository;
import com.loyalty.cconfile.entity.LpsDoclDocumentLng;;

public class AuthorizationImplementation implements IAuthorizationRepository<ClientInformationPojo, CliClientInformation> {

	@Override
	public CliClientInformation getInfoClient(ClientInformationPojo request) {
		LpsDoclDocumentLng documentType=null;
		try {
			String sql="SELECT doc FROM ClientInformationPojo doc WHERE doc.docUser=:docName";
			Query q=this.entityManager.createQuery(sql);
			q.setParameter("docName", request[0]);
			q.setParameter("lng", request[1]);
			documentType=(LpsDoclDocumentLng)q.getSingleResult();
		}catch(NoResultException nre) {
			log.warn("Microservicio: cc-onfile-svc:, error: {}",nre + " en linea: "+ nre.getStackTrace()[0].getLineNumber()+ " en metodo: "+ nre.getStackTrace()[0].getMethodName());
			return null;
		}catch (Exception e) {
			log.error("Microservicio: cc-onfile-svc:, error: {}",e + " en linea: "+ e.getStackTrace()[0].getLineNumber()+ " en metodo: "+ e.getStackTrace()[0].getMethodName());
			return null;
		}
		return documentType;
	}

	

}
