package com.loyalty.authorization.repository.implementation;

public class ClientInformationPojo {

}
