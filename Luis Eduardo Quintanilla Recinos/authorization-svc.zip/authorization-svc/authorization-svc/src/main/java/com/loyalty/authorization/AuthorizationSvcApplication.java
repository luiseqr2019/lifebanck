package com.loyalty.authorization;

import java.net.InetAddress;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;

@SpringBootApplication
public class AuthorizationSvcApplication {
	
	public static void main(String[] args) {
		try {
			System.setProperty("ip", InetAddress.getLocalHost().getHostAddress());
			SpringApplication.run(AuthorizationSvcApplication.class, args);
		}catch (Exception e) {
			e.printStackTrace();
	}
	}

}
