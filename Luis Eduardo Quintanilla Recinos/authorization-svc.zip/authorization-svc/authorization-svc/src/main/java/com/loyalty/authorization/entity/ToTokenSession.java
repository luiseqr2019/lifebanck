package com.loyalty.authorization.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.*;


/**
 * The persistent class for the to_token_session database table.
 * 
 */
@Entity
@Table(name="to_token_session")
@NamedQuery(name="ToTokenSession.findAll", query="SELECT t FROM ToTokenSession t")
public class ToTokenSession implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="to_code")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer toCode;

	@Column(name="to_expiration_date")
	private LocalDateTime toExpirationDate;

	@Column(name="to_token")
	private String toToken;

	//bi-directional many-to-one association to CliClientInformation
	@JoinColumn(name = "to_cli_code", referencedColumnName = "cli_code")
	@ManyToOne(optional = false)
	private CliClientInformation cliClientInformation;

	public ToTokenSession() {
	}

	public Integer getToCode() {
		return this.toCode;
	}

	public void setToCode(Integer toCode) {
		this.toCode = toCode;
	}

	public LocalDateTime getToExpirationDate() {
		return this.toExpirationDate;
	}

	public void setToExpirationDate(LocalDateTime toExpirationDate) {
		this.toExpirationDate = toExpirationDate;
	}

	public String getToToken() {
		return this.toToken;
	}

	public void setToToken(String toToken) {
		this.toToken = toToken;
	}

	public CliClientInformation getCliClientInformation() {
		return this.cliClientInformation;
	}

	public void setCliClientInformation(CliClientInformation cliClientInformation) {
		this.cliClientInformation = cliClientInformation;
	}

}