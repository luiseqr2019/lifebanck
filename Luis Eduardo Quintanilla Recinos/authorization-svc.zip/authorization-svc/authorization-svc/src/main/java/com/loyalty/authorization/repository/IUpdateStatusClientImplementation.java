package com.loyalty.authorization.repository;

public interface IUpdateStatusClientImplementation<I,O> {
	public O updateStatus(I request);
	public O  updateCount(I request);
	
}
