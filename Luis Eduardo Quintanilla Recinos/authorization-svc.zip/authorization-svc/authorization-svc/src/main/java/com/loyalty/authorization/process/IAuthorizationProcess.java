package com.loyalty.authorization.process;

public interface IAuthorizationProcess<I,O>{
	public O getInfoCient(I request );
}
