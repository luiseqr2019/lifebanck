package com.loyalty.authorization.repository.implementation;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.loyalty.authorization.entity.CliClientInformation;
import com.loyalty.authorization.pojo.ClientInformationPojo;
import com.loyalty.authorization.pojo.ClientInformationResponsePojo;
import com.loyalty.authorization.repository.IAuthorizationRepository;

@Service("AuthenticationImplements")
public class AuthorizationImplementation implements IAuthorizationRepository<ClientInformationPojo, CliClientInformation> {
	@PersistenceContext
	private EntityManager entityManager;
	
	private Logger log;
	
	@Autowired
	public AuthorizationImplementation(){
		this.log = LoggerFactory.getLogger(AuthorizationImplementation.class);
	}
	
	@Override
	public CliClientInformation getInfoClient(ClientInformationPojo request) {
		CliClientInformation client=null;
		ClientInformationResponsePojo response = new ClientInformationResponsePojo();
		try {
			String sql="select cli from CliClientInformation cli where cli.cliUser=:user";
			Query q=this.entityManager.createQuery(sql);
			q.setParameter("user", request.getUser());
			client=(CliClientInformation)q.getSingleResult();
			
			if(client!=null) {
				response.setUser(client.getCliUser());
				response.setPassword(client.getCliPassword());
			}else {
				return null;
			}
			
		}catch(NoResultException nre) {
			log.warn("Microservicio: Authorization-svc:, error: {}",nre + " en linea: "+ nre.getStackTrace()[0].getLineNumber()+ " en metodo: "+ nre.getStackTrace()[0].getMethodName());
			return null;
		}catch (Exception e) {
			log.error("Microservicio: Authorization-svc:, error: {}",e + " en linea: "+ e.getStackTrace()[0].getLineNumber()+ " en metodo: "+ e.getStackTrace()[0].getMethodName());
			return null;
		}
		return client;
	}

	

}
