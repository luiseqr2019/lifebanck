package com.loyalty.authorization.util;

public interface IResponse<T> {

}


