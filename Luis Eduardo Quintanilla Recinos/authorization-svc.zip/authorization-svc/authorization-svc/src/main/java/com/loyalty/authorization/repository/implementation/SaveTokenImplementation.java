package com.loyalty.authorization.repository.implementation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.loyalty.authorization.entity.CliClientInformation;
import com.loyalty.authorization.entity.ToTokenSession;
import com.loyalty.authorization.repository.ISaveTokenRepository;

@Service("SaveTokenImplementation")
public class SaveTokenImplementation {
	private ISaveTokenRepository save;
	
	@Autowired
	public SaveTokenImplementation(ISaveTokenRepository save) {
		this.save = save;
	}
	
	public void save(ToTokenSession toTokenSession){
		this.save.save(toTokenSession);
	}
	
}
