package com.loyalty.authorization.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.loyalty.authorization.pojo.ClientInformationPojo;
import com.loyalty.authorization.pojo.OutputPojo;
import com.loyalty.authorization.process.AuthorizationProcess;


@RestController
@RequestMapping("/authorization")
public class AuthorizationController {
	private AuthorizationProcess authProcess;
	
	public AuthorizationController(@Qualifier("AuthenticationProcess")AuthorizationProcess authProcess) {
		this.authProcess=authProcess;
	}

	@RequestMapping(method=RequestMethod.POST,value="/loggin")
	public ResponseEntity<OutputPojo> authentication(@RequestBody ClientInformationPojo request){
		return authProcess.getInfoCient(request);
	}
	
}
