package com.loyalty.authorization.util;

import java.util.List;

public class ListResponse<T> implements IResponse<T> {
	private String responseCode;
	private List<T> items;
	private String message;
	
	public ListResponse(){//Constructor vacio para crear objeto
	}
	
	public ListResponse(String responseCode, List<T> items){
		this.responseCode = responseCode;
		this.items=items;
	}
	
	public ListResponse(String responseCode, List<T> items,String message){
		this.responseCode = responseCode;
		this.setMessage(message);
		this.items=items;
		
	}
	
	
	public String getResponseCode() {
		return responseCode;
	}
	
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	
	
	public List<T> getItems() {
		return items;
	}

	public void setItems(List<T> items) {
		this.items = items;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
