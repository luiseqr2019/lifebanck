package com.loyalty.authorization.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import io.jsonwebtoken.SignatureAlgorithm;

public class Util {
	@Autowired
	private static Environment env;
	
	public static String encript(String request) {
		StringBuilder sb = new StringBuilder();
		try {
			MessageDigest md5 = MessageDigest.getInstance("SHA-512");
			byte[] digest = md5.digest(request.getBytes("UTF-8"));
			for (int i = 0; i < digest.length; ++i) {
			    sb.append(Integer.toHexString((digest[i] & 0xFF) | 0x100).substring(1, 3));
			 }
		}catch(Exception e){
			return "";
		}
		return sb.toString();
	}
	
	public static String base64(String a){ 
		Base64.Encoder encoder = Base64.getEncoder(); 
		String b = encoder.encodeToString(a.getBytes(StandardCharsets.UTF_8) ); 
		return b; 
	}
	

	public static String createToken(Map<String, Object> claims, Environment env) {
	return TokenBuilder.builder()
			.setSignature(SignatureAlgorithm.HS512, env.getProperty("configuration.jwt.secret"))
			.addClaims(claims)
			.build();
	}
	

	
}
