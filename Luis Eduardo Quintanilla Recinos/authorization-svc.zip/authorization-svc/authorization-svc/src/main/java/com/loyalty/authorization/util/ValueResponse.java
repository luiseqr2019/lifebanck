package com.loyalty.authorization.util;

public class ValueResponse<T,H> implements IResponse<T> {

	private H responseCode;
	private T value;
	private String message;
	
	public ValueResponse(){//Constructor vacio para crear objeto
	}
	
	public ValueResponse(H responseCode, T value){
		this.responseCode = responseCode;
		this.value=value;
	}
	
	public ValueResponse(H responseCode, T value,String message){
		this.responseCode = responseCode;
		this.value=value;
		this.setMessage(message);
	}
	
	
	public H getResponseCode() {
		return responseCode;
	}
	
	public void setResponseCode(H responseCode) {
		this.responseCode = responseCode;
	}
	
	
	public T getValue() {
		return value;
	}

	public void setValue(T value) {
		this.value = value;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}
