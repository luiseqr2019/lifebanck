package com.loyalty.authorization.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the cli_client_information database table.
 * 
 */
@Entity
@Table(name="cli_client_information")
@NamedQuery(name="CliClientInformation.findAll", query="SELECT c FROM CliClientInformation c")
public class CliClientInformation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="cli_code")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer cliCode;

	@Column(name="cli_count_session_fail")
	private Integer cliCountSessionFail;

	@Temporal(TemporalType.DATE)
	@Column(name="cli_create_date")
	private Date cliCreateDate;

	@Column(name="cli_create_user")
	private String cliCreateUser;

	@Column(name="cli_email")
	private String cliEmail;

	@Column(name="cli_last_name")
	private String cliLastName;

	@Temporal(TemporalType.DATE)
	@Column(name="cli_modify_date")
	private Date cliModifyDate;

	@Column(name="cli_modify_user")
	private String cliModifyUser;

	@Column(name="cli_name")
	private String cliName;

	@Column(name="cli_password")
	private String cliPassword;

	@Column(name="cli_status")
	private String cliStatus;

	@Column(name="cli_user")
	private String cliUser;

	//bi-directional many-to-one association to ToTokenSession
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "cliClientInformation", orphanRemoval = true)
	private List<ToTokenSession> toTokenSessions;

	public CliClientInformation() {
	}

	public Integer getCliCode() {
		return this.cliCode;
	}

	public void setCliCode(Integer cliCode) {
		this.cliCode = cliCode;
	}

	public Integer getCliCountSessionFail() {
		return this.cliCountSessionFail;
	}

	public void setCliCountSessionFail(Integer cliCountSessionFail) {
		this.cliCountSessionFail = cliCountSessionFail;
	}

	public Date getCliCreateDate() {
		return this.cliCreateDate;
	}

	public void setCliCreateDate(Date cliCreateDate) {
		this.cliCreateDate = cliCreateDate;
	}

	public String getCliCreateUser() {
		return this.cliCreateUser;
	}

	public void setCliCreateUser(String cliCreateUser) {
		this.cliCreateUser = cliCreateUser;
	}

	public String getCliEmail() {
		return this.cliEmail;
	}

	public void setCliEmail(String cliEmail) {
		this.cliEmail = cliEmail;
	}

	public String getCliLastName() {
		return this.cliLastName;
	}

	public void setCliLastName(String cliLastName) {
		this.cliLastName = cliLastName;
	}

	public Date getCliModifyDate() {
		return this.cliModifyDate;
	}

	public void setCliModifyDate(Date cliModifyDate) {
		this.cliModifyDate = cliModifyDate;
	}

	public String getCliModifyUser() {
		return this.cliModifyUser;
	}

	public void setCliModifyUser(String cliModifyUser) {
		this.cliModifyUser = cliModifyUser;
	}

	public String getCliName() {
		return this.cliName;
	}

	public void setCliName(String cliName) {
		this.cliName = cliName;
	}

	public String getCliPassword() {
		return this.cliPassword;
	}

	public void setCliPassword(String cliPassword) {
		this.cliPassword = cliPassword;
	}

	public String getCliStatus() {
		return this.cliStatus;
	}

	public void setCliStatus(String cliStatus) {
		this.cliStatus = cliStatus;
	}

	public String getCliUser() {
		return this.cliUser;
	}

	public void setCliUser(String cliUser) {
		this.cliUser = cliUser;
	}

	public List<ToTokenSession> getToTokenSessions() {
		return this.toTokenSessions;
	}

	public void setToTokenSessions(List<ToTokenSession> toTokenSessions) {
		this.toTokenSessions = toTokenSessions;
	}

	public ToTokenSession addToTokenSession(ToTokenSession toTokenSession) {
		getToTokenSessions().add(toTokenSession);
		toTokenSession.setCliClientInformation(this);

		return toTokenSession;
	}

	public ToTokenSession removeToTokenSession(ToTokenSession toTokenSession) {
		getToTokenSessions().remove(toTokenSession);
		toTokenSession.setCliClientInformation(null);

		return toTokenSession;
	}

}