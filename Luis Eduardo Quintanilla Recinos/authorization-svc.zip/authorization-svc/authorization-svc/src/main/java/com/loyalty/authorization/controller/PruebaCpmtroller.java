package com.loyalty.authorization.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/prueba")
public class PruebaCpmtroller {
	@RequestMapping(method=RequestMethod.GET,value="/prueba/{ftnum}")
	public String authentication(@PathVariable(value="ftnum") String ftnum){
		return ftnum;
	}
}
