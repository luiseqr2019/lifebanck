package com.loyalty.authorization.process;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.loyalty.authorization.entity.CliClientInformation;
import com.loyalty.authorization.entity.ToTokenSession;
import com.loyalty.authorization.pojo.ClientInformationPojo;
import com.loyalty.authorization.pojo.OutputPojo;
import com.loyalty.authorization.repository.IAuthorizationRepository;
import com.loyalty.authorization.repository.IUpdateStatusClientImplementation;
import com.loyalty.authorization.repository.implementation.SaveTokenImplementation;
import com.loyalty.authorization.util.Util;
import com.loyalty.authorization.util.ValueResponse;

@Service("AuthenticationProcess")
public class AuthorizationProcess implements IAuthorizationProcess<ClientInformationPojo,ResponseEntity<OutputPojo>> {
	
	private IAuthorizationRepository<ClientInformationPojo, CliClientInformation> implementation;
	private SaveTokenImplementation saveImplement;
	private IUpdateStatusClientImplementation<CliClientInformation, String> updImplement;
	private Environment env;
	private Logger log;
	
	public AuthorizationProcess(@Qualifier("AuthenticationImplements")IAuthorizationRepository<ClientInformationPojo, CliClientInformation> implementation,
			@Qualifier("SaveTokenImplementation") SaveTokenImplementation saveImplement,@Qualifier("UpdateImplements")IUpdateStatusClientImplementation<CliClientInformation, String> updImplement,Environment env) {
		this.implementation=implementation;
		this.saveImplement=saveImplement;
		this.updImplement=updImplement;
		this.env=env;
		this.log = LoggerFactory.getLogger(AuthorizationProcess.class);
	}
	
	@Override
	public ResponseEntity<OutputPojo> getInfoCient(ClientInformationPojo input) {
		CliClientInformation client;
		ValueResponse<OutputPojo,Integer> response=new ValueResponse<>();
		OutputPojo out=new OutputPojo();
		try {
		    
			client=implementation.getInfoClient(input);
			if(client != null) {
				
				String user = input.getUser();
				String pass= input.getPassword();
				String Encript = Util.encript(Util.base64(user) + Util.base64(pass));
				
				if(Encript.equals(client.getCliPassword())) {
					LocalDateTime expirationDate= LocalDateTime.now().plusMinutes(30);
					
					 
					Map<String, Object> map = new HashMap<>();
					map.put("expirationDate", expirationDate);
					map.put("idClient",client.getCliUser());
					map.put("ip", env.getProperty("ip"));
					
					String jwt = Util.createToken(map,env);
					out.setJwt(jwt);
					
					//guardar jwt
					ToTokenSession token = new ToTokenSession();
					token.setToToken(jwt);
					token.setToExpirationDate(expirationDate);
					token.setCliClientInformation(client);
					saveImplement.save(token);
					
				}else {
					//lamado al contador 
					Integer count = client.getCliCountSessionFail() +1;
					if (count>=5) {
						client.setCliStatus("L");
						updImplement.updateStatus(client);
						return new ResponseEntity<>(null,HttpStatus.BAD_REQUEST);
					}else {
						client.setCliCountSessionFail(count);
						//updImplement.updateCount(client);
						return new ResponseEntity<>(null,HttpStatus.UNAUTHORIZED);
					}
				}
				
				return new ResponseEntity<>(out,HttpStatus.OK);
				
			}else {
				throw new Exception("No data Result...");
			}
		} catch (Exception e) {
			log.error("Microservicio: cc-onfile-svc:, error: {}",e + " en linea: "+ e.getStackTrace()[0].getLineNumber()+ " en metodo: "+ e.getStackTrace()[0].getMethodName());
			return new ResponseEntity<>(null,HttpStatus.BAD_REQUEST);
		}
	}
	
	
	      
}
