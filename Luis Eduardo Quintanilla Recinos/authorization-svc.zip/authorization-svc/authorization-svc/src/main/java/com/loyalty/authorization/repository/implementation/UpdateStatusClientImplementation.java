package com.loyalty.authorization.repository.implementation;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transaction;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.loyalty.authorization.entity.CliClientInformation;
import com.loyalty.authorization.repository.IUpdateStatusClientImplementation;

@Service("UpdateImplements")
public class UpdateStatusClientImplementation implements IUpdateStatusClientImplementation<CliClientInformation, String> {
	@PersistenceContext
	private EntityManager entityManager;
	
	private Logger log;
	
	@Autowired
	public UpdateStatusClientImplementation(){
		this.log = LoggerFactory.getLogger(AuthorizationImplementation.class);
	}
	@Override
	@Transactional
	public String updateStatus(CliClientInformation request) {
		try {
			String sql = "update CliClientInformation cli SET cli.cliStatus = '"+request.getCliStatus()+"' WHERE cli.cliUser = :user";
			Query q=this.entityManager.createQuery(sql);
			q.setParameter("user", request.getCliUser());
			q.executeUpdate();
		}catch (Exception e) {
			log.error("Microservicio: Authorization-svc:, error: {}",e + " en linea: "+ e.getStackTrace()[0].getLineNumber()+ " en metodo: "+ e.getStackTrace()[0].getMethodName());
			return null;
		}
		return "ok";
	}
	
	
	
	@Override
	@Transactional
	public String updateCount(CliClientInformation request) {
		try {
			String sql = "UPDATE CliClientInformation cli SET cli.cliCountSessionFail=:contador WHERE cli.cliUser=:user";
			Query q=this.entityManager.createQuery(sql);
			q.setParameter("contador", request.getCliUser());
			q.setParameter("user", request.getCliUser());
			q.executeUpdate();
		}catch (Exception e) {
			log.error("Microservicio: Authorization-svc:, error: {}",e + " en linea: "+ e.getStackTrace()[0].getLineNumber()+ " en metodo: "+ e.getStackTrace()[0].getMethodName());
			return null;
		}
		return "ok";
	}

}
