package com.loyalty.authorization.repository;

import org.springframework.data.repository.CrudRepository;

import com.loyalty.authorization.entity.ToTokenSession;

public interface ISaveTokenRepository extends CrudRepository<ToTokenSession,String> {
	public ToTokenSession save(ToTokenSession toTokenSession);
}


