create user to 'usr-autentication-svc';

create schema authentication_1;



create table authentication_1.cli_client_information
(
  cli_code serial not null,
  cli_user serial not null,
  cli_name varchar(25) not null,
  cli_password varchar(50) not null,
  cli_count_session_fail integer,
  cli_status_user varchar(15),
  cli_create_user varchar(15),
  cli_create_date date,
  cli_modify_user varchar(10),
  cli_modify_date date,
  constraint cli_code primary key (cli_code)
);

create table authentication_1.to_token_session
(
  to_code serial not null,
  to_cli_code Integer not null,
  to_token serial not null,
  to_create_hour varchar(25) not null,
  to_expiration_hour varchar(50) not null,
  constraint to_code_pk primary key (to_code),
  constraint to_code_fk foreign key (to_cli_code) references authentication_1.cli_client_information(cli_code)
);

