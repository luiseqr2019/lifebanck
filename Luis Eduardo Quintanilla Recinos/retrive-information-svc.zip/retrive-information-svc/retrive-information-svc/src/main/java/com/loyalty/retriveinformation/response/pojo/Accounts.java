package com.loyalty.retriveinformation.response.pojo;

import java.util.List;

public class Accounts {
	private List<Loan> loan;
	private List<CreditCard> creditCard;
	private List<Personal> personal;
	public List<Loan> getLoan() {
		return loan;
	}
	public void setLoan(List<Loan> loan) {
		this.loan = loan;
	}
	public List<CreditCard> getCreditCard() {
		return creditCard;
	}
	public void setCreditCard(List<CreditCard> creditCard) {
		this.creditCard = creditCard;
	}
	public List<Personal> getPersonal() {
		return personal;
	}
	public void setPersonal(List<Personal> personal) {
		this.personal = personal;
	}
	
	
	
	
}
