package com.loyalty.retriveinformation.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the trac_client_transaction database table.
 * 
 */
@Entity
@Table(name="trac_client_transaction")
@NamedQuery(name="TracClientTransaction.findAll", query="SELECT t FROM TracClientTransaction t")
public class TracClientTransaction implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="trac_cod")
	private Integer tracCod;

	@Column(name="trac_account_destination")
	private String tracAccountDestination;

	@Column(name="trac_account_origin")
	private String tracAccountOrigin;

	@Column(name="trac_amount")
	private BigDecimal tracAmount;

	@Column(name="trac_description")
	private String tracDescription;

	@Column(name="trac_fecha_transaction")
	private Timestamp tracFechaTransaction;

	//bi-directional many-to-one association to AccAccoundClient
	@ManyToOne
	@JoinColumn(name="trac_acc_accound_cod")
	private AccAccoundClient accAccoundClient;

	//bi-directional one-to-one association to CliClientInformation
	@OneToOne
	@JoinColumn(name="trac_cod")
	private CliClientInformation cliClientInformation;

	//bi-directional many-to-one association to ProProduct
	@ManyToOne
	@JoinColumn(name="trac_pro_code")
	private ProProduct proProduct;

	public TracClientTransaction() {
	}

	public Integer getTracCod() {
		return this.tracCod;
	}

	public void setTracCod(Integer tracCod) {
		this.tracCod = tracCod;
	}

	public String getTracAccountDestination() {
		return this.tracAccountDestination;
	}

	public void setTracAccountDestination(String tracAccountDestination) {
		this.tracAccountDestination = tracAccountDestination;
	}

	public String getTracAccountOrigin() {
		return this.tracAccountOrigin;
	}

	public void setTracAccountOrigin(String tracAccountOrigin) {
		this.tracAccountOrigin = tracAccountOrigin;
	}

	public BigDecimal getTracAmount() {
		return this.tracAmount;
	}

	public void setTracAmount(BigDecimal tracAmount) {
		this.tracAmount = tracAmount;
	}

	public String getTracDescription() {
		return this.tracDescription;
	}

	public void setTracDescription(String tracDescription) {
		this.tracDescription = tracDescription;
	}

	public Timestamp getTracFechaTransaction() {
		return this.tracFechaTransaction;
	}

	public void setTracFechaTransaction(Timestamp tracFechaTransaction) {
		this.tracFechaTransaction = tracFechaTransaction;
	}

	public AccAccoundClient getAccAccoundClient() {
		return this.accAccoundClient;
	}

	public void setAccAccoundClient(AccAccoundClient accAccoundClient) {
		this.accAccoundClient = accAccoundClient;
	}

	public CliClientInformation getCliClientInformation() {
		return this.cliClientInformation;
	}

	public void setCliClientInformation(CliClientInformation cliClientInformation) {
		this.cliClientInformation = cliClientInformation;
	}

	public ProProduct getProProduct() {
		return this.proProduct;
	}

	public void setProProduct(ProProduct proProduct) {
		this.proProduct = proProduct;
	}

}