package com.loyalty.retriveinformation.repository.implementation;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.loyalty.retriveinformation.entity.TracClientTransaction;
import com.loyalty.retriveinformation.repository.IGetTransactionImplementation;

@Service("GetTransactionImplements")
public class GetTransactionImplement implements IGetTransactionImplementation<String, List<TracClientTransaction>>{
	@PersistenceContext
	private EntityManager entityManager;
	
	private Logger log;
	
	@Autowired
	public GetTransactionImplement(){
		this.log = LoggerFactory.getLogger(GetTransactionImplement.class);
	}
	
	@Override
	public List<TracClientTransaction> getInfoTransaction(String... request) {
		List<TracClientTransaction> transactionList= null;
		
		try {

			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
			
			String sql="select tra from TracClientTransaction tra "
					+ "where tra.accAccoundClient.accAccoundNumber=:account "
					+ "and tra.tracFechaTransaction between :startDate and :endDate "
					+ "order by tra.tracFechaTransaction DESC";
			Query q=this.entityManager.createQuery(sql);
			q.setParameter("account", request[0]);
			q.setParameter("startDate", formatter.parse(request[1]));
			q.setParameter("endDate", formatter.parse(request[2]));
			transactionList=q.getResultList();
		}catch (Exception e) {
			log.error("error en el retrive-information-svc: {}",e);
			return null;
		}
		return transactionList;
	}

}
