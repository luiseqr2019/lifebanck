package com.loyalty.retriveinformation;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetriveInformationSvcApplication {

	public static void main(String[] args) {
		try {
			System.setProperty("ip", InetAddress.getLocalHost().getHostAddress());
			SpringApplication.run(RetriveInformationSvcApplication.class, args);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		
	}

}
