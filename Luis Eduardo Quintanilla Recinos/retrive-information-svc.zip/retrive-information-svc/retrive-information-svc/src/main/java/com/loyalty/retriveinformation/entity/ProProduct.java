package com.loyalty.retriveinformation.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the pro_product database table.
 * 
 */
@Entity
@Table(name="pro_product")
@NamedQuery(name="ProProduct.findAll", query="SELECT p FROM ProProduct p")
public class ProProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="pro_code")
	private Integer proCode;

	@Column(name="pro_type_product")
	private String proTypeProduct;

	//bi-directional many-to-one association to DproDetalleProduct
	@OneToMany(mappedBy="proProduct")
	private List<DproDetalleProduct> dproDetalleProducts;

	//bi-directional many-to-one association to CliClientInformation
	@ManyToOne
	@JoinColumn(name="pro_user")
	private CliClientInformation cliClientInformation;

	//bi-directional many-to-one association to TracClientTransaction
	@OneToMany(mappedBy="proProduct")
	private List<TracClientTransaction> tracClientTransactions;

	public ProProduct() {
	}

	public Integer getProCode() {
		return this.proCode;
	}

	public void setProCode(Integer proCode) {
		this.proCode = proCode;
	}

	public String getProTypeProduct() {
		return this.proTypeProduct;
	}

	public void setProTypeProduct(String proTypeProduct) {
		this.proTypeProduct = proTypeProduct;
	}

	public List<DproDetalleProduct> getDproDetalleProducts() {
		return this.dproDetalleProducts;
	}

	public void setDproDetalleProducts(List<DproDetalleProduct> dproDetalleProducts) {
		this.dproDetalleProducts = dproDetalleProducts;
	}

	public DproDetalleProduct addDproDetalleProduct(DproDetalleProduct dproDetalleProduct) {
		getDproDetalleProducts().add(dproDetalleProduct);
		dproDetalleProduct.setProProduct(this);

		return dproDetalleProduct;
	}

	public DproDetalleProduct removeDproDetalleProduct(DproDetalleProduct dproDetalleProduct) {
		getDproDetalleProducts().remove(dproDetalleProduct);
		dproDetalleProduct.setProProduct(null);

		return dproDetalleProduct;
	}

	public CliClientInformation getCliClientInformation() {
		return this.cliClientInformation;
	}

	public void setCliClientInformation(CliClientInformation cliClientInformation) {
		this.cliClientInformation = cliClientInformation;
	}

	public List<TracClientTransaction> getTracClientTransactions() {
		return this.tracClientTransactions;
	}

	public void setTracClientTransactions(List<TracClientTransaction> tracClientTransactions) {
		this.tracClientTransactions = tracClientTransactions;
	}

	public TracClientTransaction addTracClientTransaction(TracClientTransaction tracClientTransaction) {
		getTracClientTransactions().add(tracClientTransaction);
		tracClientTransaction.setProProduct(this);

		return tracClientTransaction;
	}

	public TracClientTransaction removeTracClientTransaction(TracClientTransaction tracClientTransaction) {
		getTracClientTransactions().remove(tracClientTransaction);
		tracClientTransaction.setProProduct(null);

		return tracClientTransaction;
	}

}