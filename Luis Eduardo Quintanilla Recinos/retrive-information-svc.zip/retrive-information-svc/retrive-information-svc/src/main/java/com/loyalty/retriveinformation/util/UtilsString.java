package com.loyalty.retriveinformation.util;

import org.slf4j.Logger;
import org.springframework.core.env.Environment;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureException;

public class UtilsString {
	
	public static int validateJwt(String jwt, String ipAdd, Environment env, Logger log) {
		try {
			Claims claim = (Claims) Jwts.parser().setSigningKey(env.getProperty("configuration.jwt.secret")).parse(jwt).getBody();
			String ip = claim.get("ip").toString();
			if(!ip.equals(ipAdd)) {
				log.error("IP doesn't match, error: {}", 403);
				return 403;
			}
		} catch (SignatureException e) {
			log.error("Signature doesn't match, error: {}", 403);
			log.error("Microservicio Retrive-information-svc:  error: {} en linea: {} en metodo: {}", e,
					e.getStackTrace()[0].getLineNumber(), e.getStackTrace()[0].getMethodName());
			return 403;
		}catch(ExpiredJwtException e){
			log.error("Expiration date, error: {}", 440);
			log.error("Microservicio Retrive-information-svc:  error: {} en linea: {} en metodo: {}", e,
					e.getStackTrace()[0].getLineNumber(), e.getStackTrace()[0].getMethodName());
			return 440;
		}
		log.error("validate SUCCESS: {}", 200);
		return 200;
	}
}
