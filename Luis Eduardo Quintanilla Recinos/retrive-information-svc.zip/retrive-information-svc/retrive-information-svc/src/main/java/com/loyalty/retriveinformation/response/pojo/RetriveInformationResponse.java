package com.loyalty.retriveinformation.response.pojo;

public class RetriveInformationResponse {
	private Accounts accounts;

	public Accounts getAccounts() {
		return accounts;
	}

	public void setAccounts(Accounts accounts) {
		this.accounts = accounts;
	}
}
