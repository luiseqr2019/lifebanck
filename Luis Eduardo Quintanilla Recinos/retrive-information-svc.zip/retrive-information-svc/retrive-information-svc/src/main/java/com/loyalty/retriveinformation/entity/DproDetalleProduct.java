package com.loyalty.retriveinformation.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the dpro_detalle_product database table.
 * 
 */
@Entity
@Table(name="dpro_detalle_product")
@NamedQuery(name="DproDetalleProduct.findAll", query="SELECT d FROM DproDetalleProduct d")
public class DproDetalleProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="dpro_code")
	private Integer dproCode;

	@Column(name="dpro_id")
	private String dproId;

	@Column(name="dpro_name")
	private String dproName;

	//bi-directional many-to-one association to ProProduct
	@ManyToOne
	@JoinColumn(name="dpro_pro_code")
	private ProProduct proProduct;

	public DproDetalleProduct() {
	}

	public Integer getDproCode() {
		return this.dproCode;
	}

	public void setDproCode(Integer dproCode) {
		this.dproCode = dproCode;
	}

	public String getDproId() {
		return this.dproId;
	}

	public void setDproId(String dproId) {
		this.dproId = dproId;
	}

	public String getDproName() {
		return this.dproName;
	}

	public void setDproName(String dproName) {
		this.dproName = dproName;
	}

	public ProProduct getProProduct() {
		return this.proProduct;
	}

	public void setProProduct(ProProduct proProduct) {
		this.proProduct = proProduct;
	}

}