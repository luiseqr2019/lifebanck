package com.loyalty.retriveinformation.repository;

public interface IGetTransactionImplementation<I, O> {
	public O getInfoTransaction(I... request );
}
