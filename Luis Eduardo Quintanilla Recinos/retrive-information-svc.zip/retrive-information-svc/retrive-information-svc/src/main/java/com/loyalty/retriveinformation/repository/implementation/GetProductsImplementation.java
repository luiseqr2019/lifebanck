package com.loyalty.retriveinformation.repository.implementation;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.loyalty.retriveinformation.entity.ProProduct;
import com.loyalty.retriveinformation.repository.IGetPruductsImplementation;

@Service("GetProductsImplements")
public class GetProductsImplementation implements IGetPruductsImplementation<String, List<ProProduct>>{
	@PersistenceContext
	private EntityManager entityManager;
	

	private Logger log;
	
	@Autowired
	public GetProductsImplementation(){
		this.log = LoggerFactory.getLogger(GetProductsImplementation.class);
	}
	

	@Override
	public List<ProProduct> getInfoProducts(String request) {
		List<ProProduct> ProProductList = null;
		try {
			String sql="select pro from ProProduct pro "
					+ "where pro.cliClientInformation.cliUser=:user";
			Query q=this.entityManager.createQuery(sql);
			q.setParameter("user", request);
			ProProductList=q.getResultList();
		}catch (Exception e) {
			log.error("error en el retrive-information-svc: {}",e);
			return null;
		}
		return ProProductList;
	}
	
}
