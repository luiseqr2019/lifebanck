 package com.loyalty.retriveinformation.process;

public interface IGetProductsProcess<I, O> {
	public O getInfoProducts(I... request );
}
