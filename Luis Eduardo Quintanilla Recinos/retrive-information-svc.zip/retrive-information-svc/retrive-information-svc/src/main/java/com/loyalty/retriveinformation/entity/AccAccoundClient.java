package com.loyalty.retriveinformation.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the acc_accound_client database table.
 * 
 */
@Entity
@Table(name="acc_accound_client")
@NamedQuery(name="AccAccoundClient.findAll", query="SELECT a FROM AccAccoundClient a")
public class AccAccoundClient implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="acc_cod")
	private Integer accCod;

	@Column(name="acc_accound_limit")
	private BigDecimal accAccoundLimit;

	@Column(name="acc_accound_number")
	private String accAccoundNumber;

	@Column(name="acc_amount")
	private BigDecimal accAmount;

	//bi-directional many-to-one association to CliClientInformation
	@ManyToOne
	@JoinColumn(name="acc_cli_code")
	private CliClientInformation cliClientInformation;

	//bi-directional many-to-one association to TracClientTransaction
	@OneToMany(mappedBy="accAccoundClient")
	private List<TracClientTransaction> tracClientTransactions;

	public AccAccoundClient() {
	}

	public Integer getAccCod() {
		return this.accCod;
	}

	public void setAccCod(Integer accCod) {
		this.accCod = accCod;
	}

	public BigDecimal getAccAccoundLimit() {
		return this.accAccoundLimit;
	}

	public void setAccAccoundLimit(BigDecimal accAccoundLimit) {
		this.accAccoundLimit = accAccoundLimit;
	}

	public String getAccAccoundNumber() {
		return this.accAccoundNumber;
	}

	public void setAccAccoundNumber(String accAccoundNumber) {
		this.accAccoundNumber = accAccoundNumber;
	}

	public BigDecimal getAccAmount() {
		return this.accAmount;
	}

	public void setAccAmount(BigDecimal accAmount) {
		this.accAmount = accAmount;
	}

	public CliClientInformation getCliClientInformation() {
		return this.cliClientInformation;
	}

	public void setCliClientInformation(CliClientInformation cliClientInformation) {
		this.cliClientInformation = cliClientInformation;
	}

	public List<TracClientTransaction> getTracClientTransactions() {
		return this.tracClientTransactions;
	}

	public void setTracClientTransactions(List<TracClientTransaction> tracClientTransactions) {
		this.tracClientTransactions = tracClientTransactions;
	}

	public TracClientTransaction addTracClientTransaction(TracClientTransaction tracClientTransaction) {
		getTracClientTransactions().add(tracClientTransaction);
		tracClientTransaction.setAccAccoundClient(this);

		return tracClientTransaction;
	}

	public TracClientTransaction removeTracClientTransaction(TracClientTransaction tracClientTransaction) {
		getTracClientTransactions().remove(tracClientTransaction);
		tracClientTransaction.setAccAccoundClient(null);

		return tracClientTransaction;
	}

}