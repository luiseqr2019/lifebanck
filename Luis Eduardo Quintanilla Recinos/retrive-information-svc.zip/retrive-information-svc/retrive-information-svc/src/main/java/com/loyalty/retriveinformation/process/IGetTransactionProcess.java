package com.loyalty.retriveinformation.process;

public interface IGetTransactionProcess<I, O> {
	public O getInfoTransaction(I... request );
}
