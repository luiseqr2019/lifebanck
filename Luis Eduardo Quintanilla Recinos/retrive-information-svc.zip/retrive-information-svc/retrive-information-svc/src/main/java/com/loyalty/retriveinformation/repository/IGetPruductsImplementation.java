package com.loyalty.retriveinformation.repository;

public interface IGetPruductsImplementation<I,O> {
	public O getInfoProducts(I request );
}
