package com.loyalty.retriveinformation.process;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.loyalty.retriveinformation.entity.DproDetalleProduct;
import com.loyalty.retriveinformation.entity.ProProduct;
import com.loyalty.retriveinformation.repository.IGetPruductsImplementation;
import com.loyalty.retriveinformation.response.pojo.Accounts;
import com.loyalty.retriveinformation.response.pojo.CreditCard;
import com.loyalty.retriveinformation.response.pojo.Loan;
import com.loyalty.retriveinformation.response.pojo.Personal;
import com.loyalty.retriveinformation.response.pojo.RetriveInformationResponse;
import com.loyalty.retriveinformation.util.UtilsString;

@Service("GetProductProcess")
public class GetProductsProcess implements IGetProductsProcess<String,ResponseEntity<RetriveInformationResponse>> {
	private IGetPruductsImplementation<String,List<ProProduct>> implementation;
	private Logger log;
	private Environment env;
	
	public GetProductsProcess(@Qualifier("GetProductsImplements")IGetPruductsImplementation<String, List<ProProduct>> implementation, Environment env) {
		this.implementation=implementation;
		this.env=env;
		this.log = LoggerFactory.getLogger(GetProductsProcess.class);
	}
	
	
	@Override
	public ResponseEntity<RetriveInformationResponse> getInfoProducts(String... request) {
		RetriveInformationResponse res =new RetriveInformationResponse();
		Accounts accounts = new Accounts();
		List<ProProduct> ProProductList = null;
		
		if(UtilsString.validateJwt(request[1], env.getProperty("ip"), env, log)!=200) {
			return new ResponseEntity<>(null,HttpStatus.BAD_REQUEST);
		}
		
		try {
			ProProductList=implementation.getInfoProducts(request[0]);
			if(ProProductList!=null && !ProProductList.isEmpty()) {
				List<Loan> loanList = new ArrayList<>();
				List<CreditCard> ccList = new ArrayList<>();
				List<Personal> personalList = new ArrayList<>();
				for (ProProduct pro : ProProductList) {
					for (DproDetalleProduct detalle : pro.getDproDetalleProducts()) {
						Loan loan=new Loan();
						CreditCard cc =new CreditCard();
						Personal pp=new Personal();
						switch (pro.getProTypeProduct()) {
							case "loan":
								loan.setId(detalle.getDproId());
								loan.setName(detalle.getDproName());
								loanList.add(loan);
								break;
							case "creditcard":
								cc.setId(detalle.getDproId());
								cc.setName(detalle.getDproName());
								ccList.add(cc);
								break;
							case "personal":
								pp.setId(detalle.getDproId());
								pp.setName(detalle.getDproName());
								personalList.add(pp);
								break;
						}
					}
					
					
				}
				accounts.setLoan(loanList);
				accounts.setCreditCard(ccList);
				accounts.setPersonal(personalList);
				res.setAccounts(accounts);
			}else {
				return new ResponseEntity<>(null,HttpStatus.BAD_REQUEST);
			}
		}catch (Exception e) {
			log.error("Error servicio retrive-information-svc: {}",e);
			return new ResponseEntity<>(null,HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(res,HttpStatus.OK);
	}
	
}
