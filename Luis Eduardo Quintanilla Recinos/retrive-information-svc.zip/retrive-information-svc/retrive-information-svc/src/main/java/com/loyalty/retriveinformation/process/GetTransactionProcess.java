package com.loyalty.retriveinformation.process;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.loyalty.retriveinformation.entity.TracClientTransaction;
import com.loyalty.retriveinformation.repository.IGetTransactionImplementation;
import com.loyalty.retriveinformation.response.transaction.pojo.TransactionResponsePojo;
import com.loyalty.retriveinformation.util.UtilsString;

@Service("GetTransactionProcess")
public class GetTransactionProcess implements IGetTransactionProcess<String,ResponseEntity<TracClientTransaction>>{
	private IGetTransactionImplementation<String,List<TracClientTransaction>> implementation;
	private Logger log;
	private Environment env;
	
	public GetTransactionProcess(@Qualifier("GetTransactionImplements")IGetTransactionImplementation<String,List<TracClientTransaction>> implementation, Environment env) {
		this.implementation=implementation;
		this.env=env;
		this.log = LoggerFactory.getLogger(GetProductsProcess.class);
	}

	@Override
	public ResponseEntity<TracClientTransaction> getInfoTransaction(String... request) {
		TransactionResponsePojo res =new TransactionResponsePojo();
		List<TracClientTransaction> resList = null;
		
		if(UtilsString.validateJwt(request[3], env.getProperty("ip"), env, log)!=200) {
			return new ResponseEntity<>(null,HttpStatus.BAD_REQUEST);
		}
		
		try {
			DateTimeFormatter formatterFechaIni = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			LocalDate start = LocalDate.parse(request[1], formatterFechaIni);
			LocalDate end = LocalDate.parse(request[2], formatterFechaIni);
			
			if(!validarRangoFechas(start,end)) {
				return new ResponseEntity<>(null,HttpStatus.BAD_REQUEST);
				
			}
			
			
			resList=implementation.getInfoTransaction(request);
			if(resList!=null && !resList.isEmpty()) {
				return new ResponseEntity<>(resList.get(0),HttpStatus.OK);
				
			}
			
			
		}catch (Exception e) {
			log.error("Error en el servicio retrive-information-svc: {}",e);
			return new ResponseEntity<>(null,HttpStatus.BAD_REQUEST);
		}
		return null;
	}
	
	public boolean validarRangoFechas(LocalDate fechaInicialConsulta,LocalDate fechaFinConsulta){
        if(fechaInicialConsulta.isBefore(fechaFinConsulta) && (fechaFinConsulta.isBefore(fechaInicialConsulta.plusMonths(3)) ||fechaFinConsulta.isEqual(fechaInicialConsulta.plusMonths(3)))){
            return true;
        }else{
            return false;
        }
    }

	
}
